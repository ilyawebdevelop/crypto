//SWIPER SLIDER
const swiper = new Swiper('.advantages__cards', {    
  speed: 400,
  spaceBetween: 0,
  slidesPerView: 4,
  loop: true,	 
  loopFillGroupWithBlank: true,
  
  breakpoints: {
    320: {
        slidesPerView: 1,
        spaceBetween: 0,
        allowTouchMove:true,
        pagination: {    
          el: ".swiper-pagination",
          type: "bullets",
          clickable: true,
        },
    },
    767: {
      slidesPerView: 2,
      pagination: {    
        el: ".swiper-pagination",
        type: "bullets",
        clickable: true,
      },
    },
    1199: {
        slidesPerView: 3,
        spaceBetween: 0,
        allowTouchMove: true,
        pagination: {    
          el: ".swiper-pagination",
          type: "bullets",
          clickable: true,
        },        
    },
    1400: {
      slidesPerView: 4,
      allowTouchMove:false,   
    }
  }
  
});